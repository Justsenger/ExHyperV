namespace ExHyperV.Views.Pages;
using System;
using System.Management.Automation;
using System.Windows;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Windows.Controls;
using System.Xml.Linq;
using static ExHyperV.Views.Pages.DDAPage;
using System.Numerics;

public partial class GPUPage
{

    public GPUPage()
    {
        InitializeComponent();     
        Task.Run(() => GetGpu());
    }

    public class GPUInfo
    {
        public string Name { get; set; } //�Կ�����
        public string Valid { get; set; } //�Ƿ�����
        public string Manu { get; set; } //����
        public string InstanceId { get; set; } //�Կ�ʵ��id
        public string Pname { get; set; } //�ɷ������Կ�·��
        public string Ram { get; set; } //�Դ��С

        // ���캯��
        public GPUInfo(string name, string valid, string manu, string instanceId, string pname, string ram)
        {
            Name = name;
            Valid = valid;
            Manu = manu;
            InstanceId = instanceId;
            Pname = pname;
            Ram = ram;
        }

    }


    public async void GetGpu()
    {
        List<GPUInfo> gpuList = new List<GPUInfo>();
        PowerShell ps = PowerShell.Create();
        //��ȡĿǰ�������Կ�
        string script0 = "Get-WmiObject -Class Win32_VideoController | select PNPDeviceID,name";
        ps.AddScript(script0);
        var result = ps.Invoke();
        if (result.Count > 0)
        {
            foreach (var gpu in result)
            {
                string name = gpu.Members["name"]?.Value.ToString();
                string instanceId = gpu.Members["PNPDeviceID"]?.Value.ToString();
                gpuList.Add(new GPUInfo(name, "True", null, instanceId, null,null));
                
            }
        }

        //��ȡN���Դ�
        string script = $@"$output = nvidia-smi --query-gpu=name,memory.total --format=csv,noheader,nounits
            $gpuList = @()
            foreach ($line in $output) {{ 
            $gpuInfo = $line -split ',' 
            $gpuName = $gpuInfo[0].Trim() 
            $memory = $gpuInfo[1].Trim() 
            $gpuList += [PSCustomObject]@{{ 
                DriverDesc = $gpuName 
                MemorySize = $memory 
                    }}
                }}
            $gpuList";
        ps.AddScript(script);
        var result2 = ps.Invoke();
        if (result2.Count > 0)
        {
            foreach (var gpu in result2)
            {
                string driverDesc = gpu.Members["DriverDesc"]?.Value.ToString();
                string memorySize = gpu.Members["MemorySize"]?.Value.ToString();

                var existingGpu = gpuList.FirstOrDefault(g => g.Name == driverDesc); //ѡ�������Կ��е������Կ�
                if (existingGpu != null) //ֻ�������Կ��Ÿ���
                {
                    existingGpu.Ram = memorySize;
                }
            }
        }
        //��ȡ�ɷ���GPU����
        string script1 = "Get-VMHostPartitionableGpu | select name";
        ps.AddScript(script1);
        var result3 = ps.Invoke();
        if (result3.Count > 0)
        {
            foreach (var gpu in result3)
            {
                string pname = gpu.Members["Name"]?.Value.ToString();
                var existingGpu = gpuList.FirstOrDefault(g => pname.ToUpper().Contains(g.InstanceId.Replace("\\", "#")));  // �ҵ� pname ��Ӧ���Կ�
                if (existingGpu != null)
                {
                    existingGpu.Pname = pname;
                }
            }
        }

        // ��� gpuList ����
        foreach (var gpu in gpuList)
        {
            MessageBox.Show($"�Կ���: {gpu.Name}, �Ƿ���Ч: {gpu.Valid}, ������: {gpu.Manu}, ʵ��ID: {gpu.InstanceId}, �ɷ���·��: {gpu.Pname}, �Դ��С: {gpu.Ram}");
        }

    }
}
    





    
